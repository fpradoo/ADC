<?php 
// silent is good 
 ?>